module.exports = {
  extends: ['plugin:prettier/recommended'],
};