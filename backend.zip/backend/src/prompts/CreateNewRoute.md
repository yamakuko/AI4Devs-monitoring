Basándote en las buenas prácticas del manifesto @ManifestoBuenasPracticas.md , dame las instrucciones detalladas para crear un nuevo endpoint GET /position/:id/candidates

Sé específico en los archivos donde va cada código. 
Dame la respuesta en espanol.

Contexto del proyecto:
@backend 